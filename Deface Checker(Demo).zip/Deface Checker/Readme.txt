-----------------------------------------------------------------------------
Release Date:
04/09/2016 11:42PM (GMT+6)
-----------------------------------------------------------------------------
This program is a demo program.
Language:
* Python
-----------------------------------------------------------------------------
Features:
* Scans defaced websites and puts them in a file
* Not defaced urls are listed in another file
* Finally the program opens both new lists of hacked and not hacked websites.
-----------------------------------------------------------------------------
Bugs:
* only scans active domains
* if your list contains any dead urls, you will encounter an error
We are working hard to improve this problem.Stay tuned.
facebook.com/wax.vampire
-----------------------------------------------------------------------------
